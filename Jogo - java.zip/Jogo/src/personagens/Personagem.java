/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personagens;

import armas.ArmaIF;

/**
 *
 * @author aluno
 */
public abstract class Personagem {
    
    ArmaIF arma;
    public abstract void desenhar();
    public void falar(){
        System.out.println("Olá!");
    }
    
    public void setArma(ArmaIF a){
        arma = a;
    }
    
    public void arma(){
        arma.usarArma();
    }
    
    public void novaArma(){
        arma.usarArma();
    }
    
    public void fogo(){
        arma.usarArma();
    }
   
}
