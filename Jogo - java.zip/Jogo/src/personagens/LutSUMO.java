/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personagens;

/**
 *
 * @author aluno
 */
public class LutSUMO extends Personagem{

    @Override
    public void desenhar() {
        System.out.println("Lutador de Sumô");
        System.out.println("   O ");
        System.out.println("/|||||\\ ");
        System.out.println(" ||||| ");
        System.out.println("/     \\ ");
        
    }
    
    @Override
    public void arma(){
        System.out.println("Desarmado");
    }
    
    @Override
    public void novaArma(){
        System.out.println("Facada");
    }
    
}
