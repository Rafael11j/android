package jogo;

import armas.Desarmado;
import armas.Fuzil;
import armas.Magia;
import armas.Revolver;
import personagens.General;
import personagens.LutSUMO;
import personagens.Mago;
import personagens.Personagem;
import personagens.Soldado;


public class UsaPersonagem {

    
    public static void main(String[] args) {
        
        Personagem p = new Soldado();
        p.desenhar();
        p.falar();
        p.setArma(new Revolver());
        p.arma();
        p.novaArma();
        System.out.println("\n\n");
        p = new General();
        p.desenhar();
        p.falar();
        p.setArma(new Fuzil());
        p.arma();
        p.novaArma();
        System.out.println("\n\n");
        p = new LutSUMO();
        p.desenhar();
        p.falar();
        p.setArma(new Desarmado());
        p.arma();
        p.novaArma();
        System.out.println("\n\n");
        p = new Mago();
        p.desenhar();
        p.falar();
        p.setArma(new Magia());
        p.arma();
        
        
    }
    
}
