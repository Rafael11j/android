/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package armas;

/**
 *
 * @author aluno
 */
public class Faca implements ArmaIF{

    @Override
    public void usarArma() {
        System.out.println("Facada");
    }
    
}
