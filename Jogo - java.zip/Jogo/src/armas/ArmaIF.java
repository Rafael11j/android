package armas;

public interface ArmaIF {
    
    void usarArma();
    
}
